//
//  NearMeApp.swift
//  NearMe
//
//  Created by Mohammad Azam on 5/5/21.
//

import SwiftUI

@main
struct NearMeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
